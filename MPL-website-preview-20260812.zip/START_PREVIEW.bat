@echo off
setlocal
cd /d "%~dp0"

echo Starting the MPL website preview...
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0preview-server.ps1"

if errorlevel 1 (
  echo.
  echo The preview could not be started.
  echo Please keep this folder extracted and try again.
  pause
)

