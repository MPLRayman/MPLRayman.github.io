param(
    [int]$Port = 4173,
    [switch]$NoBrowser
)

$ErrorActionPreference = 'Stop'
$root = [IO.Path]::GetFullPath($PSScriptRoot + [IO.Path]::DirectorySeparatorChar)
$listener = $null

for ($candidate = $Port; $candidate -lt ($Port + 30); $candidate++) {
    try {
        $listener = [Net.Sockets.TcpListener]::new([Net.IPAddress]::Loopback, $candidate)
        $listener.Start()
        $Port = $candidate
        break
    }
    catch {
        if ($listener) {
            $listener.Stop()
            $listener = $null
        }
    }
}

if (-not $listener) {
    throw 'No available local port was found.'
}

function Get-ContentType([string]$path) {
    switch ([IO.Path]::GetExtension($path).ToLowerInvariant()) {
        '.html' { 'text/html; charset=utf-8' }
        '.css'  { 'text/css; charset=utf-8' }
        '.js'   { 'application/javascript; charset=utf-8' }
        '.json' { 'application/json; charset=utf-8' }
        '.svg'  { 'image/svg+xml' }
        '.png'  { 'image/png' }
        '.jpg'  { 'image/jpeg' }
        '.jpeg' { 'image/jpeg' }
        '.gif'  { 'image/gif' }
        '.webp' { 'image/webp' }
        '.ico'  { 'image/x-icon' }
        '.woff' { 'font/woff' }
        '.woff2'{ 'font/woff2' }
        default { 'application/octet-stream' }
    }
}

function Write-Response(
    [Net.Sockets.NetworkStream]$stream,
    [int]$statusCode,
    [string]$statusText,
    [string]$contentType,
    [byte[]]$body,
    [bool]$includeBody
) {
    $header = "HTTP/1.1 $statusCode $statusText`r`n" +
              "Content-Type: $contentType`r`n" +
              "Content-Length: $($body.Length)`r`n" +
              "Cache-Control: no-store`r`n" +
              "Connection: close`r`n`r`n"
    $headerBytes = [Text.Encoding]::ASCII.GetBytes($header)
    $stream.Write($headerBytes, 0, $headerBytes.Length)
    if ($includeBody -and $body.Length -gt 0) {
        $stream.Write($body, 0, $body.Length)
    }
}

$url = "http://127.0.0.1:$Port/"
Write-Host ''
Write-Host "MPL website preview: $url"
Write-Host 'Keep this window open while viewing the site.'
Write-Host 'Press Ctrl+C or close this window to stop the preview.'
Write-Host ''

if (-not $NoBrowser) {
    Start-Process $url
}

try {
    while ($true) {
        $client = $listener.AcceptTcpClient()
        $stream = $null
        $reader = $null
        try {
            $stream = $client.GetStream()
            $reader = [IO.StreamReader]::new($stream, [Text.Encoding]::ASCII, $false, 1024, $true)
            $requestLine = $reader.ReadLine()

            while ($reader.ReadLine()) {
                # Consume request headers.
            }

            if ([string]::IsNullOrWhiteSpace($requestLine)) {
                continue
            }

            $request = $requestLine.Split(' ')
            $method = $request[0]
            $target = $request[1].Split('?')[0]

            if ($method -ne 'GET' -and $method -ne 'HEAD') {
                $body = [Text.Encoding]::UTF8.GetBytes('Method not allowed')
                Write-Response $stream 405 'Method Not Allowed' 'text/plain; charset=utf-8' $body ($method -ne 'HEAD')
                continue
            }

            $decodedPath = [Uri]::UnescapeDataString($target)
            if ($decodedPath -eq '/') {
                $decodedPath = '/index.html'
            }

            $relativePath = $decodedPath.TrimStart('/').Replace('/', [IO.Path]::DirectorySeparatorChar)
            $filePath = [IO.Path]::GetFullPath((Join-Path $root $relativePath))

            if (-not $filePath.StartsWith($root, [StringComparison]::OrdinalIgnoreCase)) {
                $body = [Text.Encoding]::UTF8.GetBytes('Forbidden')
                Write-Response $stream 403 'Forbidden' 'text/plain; charset=utf-8' $body ($method -ne 'HEAD')
                continue
            }

            if (Test-Path -LiteralPath $filePath -PathType Container) {
                $filePath = Join-Path $filePath 'index.html'
            }

            if (-not (Test-Path -LiteralPath $filePath -PathType Leaf)) {
                $body = [Text.Encoding]::UTF8.GetBytes('Not found')
                Write-Response $stream 404 'Not Found' 'text/plain; charset=utf-8' $body ($method -ne 'HEAD')
                continue
            }

            $body = [IO.File]::ReadAllBytes($filePath)
            Write-Response $stream 200 'OK' (Get-ContentType $filePath) $body ($method -ne 'HEAD')
        }
        catch {
            Write-Warning $_.Exception.Message
        }
        finally {
            if ($reader) { $reader.Dispose() }
            if ($stream) { $stream.Dispose() }
            $client.Close()
        }
    }
}
finally {
    $listener.Stop()
}
